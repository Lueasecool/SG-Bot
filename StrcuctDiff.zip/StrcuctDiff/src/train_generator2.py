from torch.utils.data import DataLoader
import argparse
from omegaconf import OmegaConf
import pytorch_lightning as pl
from pytorch_lightning.loggers import WandbLogger
from pytorch_lightning.callbacks import ModelCheckpoint

# from StructDiffusion.data.semantic_arrangement import SemanticArrangementDataset
from StructDiffusion.language.tokenizer import Tokenizer
from StructDiffusion.models.pl_models import ConditionalPoseDiffusionModel
from data_readfull import my_Dataset


#sample方法的代码，两种
#三种方法的可视化需要统一

#艰难的调参过程。。。

#open API接口调用
#实体部署，视觉识别抓取和放置（！！！！）


#在训练和推理中，sde模型中输入和输出应该是什么


#统一，用可视化的库渲染场景
#分开测试集，记录指标


def main(cfg):

    pl.seed_everything(cfg.random_seed)

    wandb_logger = WandbLogger(**cfg.WANDB)
    wandb_logger.experiment.config.update(cfg)
    checkpoint_callback = ModelCheckpoint()

    tokenizer = Tokenizer('/home/lyb/PythonProject/StructDiffusion/testing_data/type_vocabs_coarse.json')
    vocab_size = tokenizer.get_vocab_size()

    root="/home/lyb/PythonProject/ArrangeBot/sgbot_dataset/raw"
    train_file_path='/home/lyb/PythonProject/ArrangeBot/sgbot_dataset/train_scenes.txt'

    # train_dataset = SemanticArrangementDataset(split="train", tokenizer=tokenizer, **cfg.DATASET)
    # valid_dataset = SemanticArrangementDataset(split="valid", tokenizer=tokenizer, **cfg.DATASET)
    train_dataset = my_Dataset(root,train_file_path,None,None)
    
    valid_dataset = my_Dataset(root,train_file_path,None,None)
    
   
    train_dataloader = DataLoader(train_dataset, shuffle=True, **cfg.DATALOADER)
    valid_dataloader = DataLoader(valid_dataset, shuffle=False, **cfg.DATALOADER)

    model = ConditionalPoseDiffusionModel(vocab_size, cfg.MODEL, cfg.LOSS, cfg.NOISE_SCHEDULE, cfg.OPTIMIZER)

    trainer = pl.Trainer(logger=wandb_logger, callbacks=[checkpoint_callback],**cfg.TRAINER)

    trainer.fit(model, train_dataloaders=train_dataloader)




if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="train")
    parser.add_argument("--base_config_file", help='base config yaml file',
                        default='./configs/base.yaml',
                        type=str)
    parser.add_argument("--config_file", help='config yaml file',
                        default='./configs/conditional_pose_diffusion.yaml',
                        type=str)
    

    args = parser.parse_args()
    base_cfg = OmegaConf.load(args.base_config_file)
    cfg = OmegaConf.load(args.config_file)
    cfg = OmegaConf.merge(base_cfg, cfg)

    main(cfg)