
from __future__ import print_function
import torch.utils.data as data
import os
import os.path
import torch
import numpy as np
import copy
import sys
import torch.nn.utils.rnn as rnn_utils
#import graphto3d.dataset.util as util
from tqdm import tqdm
import json
sys.path.append('./src')
sys.path.append('./StructDiffusion')
#from graphto3d.helpers.psutil import FreeMemLinux
#from graphto3d.helpers.util import normalize_box_params
import random
import pickle
from scipy.spatial.transform import Rotation as R
# from scripts.train_iter.utils import normalize_box_params
def normalize_box_params(box_params, scale=3):
    """ Normalize the box parameters for more stable learning utilizing the accumulated dataset statistics

    :param box_params: float array of shape [7] containing the box parameters
    :param scale: float scalar that scales the parameter distribution
    :return: normalized box parameters array of shape [7]
    """
    mean = np.array([ 0.2610482 ,  0.22473196,  0.14623462,  0.0010283 , -0.02288815 , 0.20876316])#np.array([ 2.42144732e-01,  2.35105852e-01,  1.53590141e-01, -1.54968627e-04, -2.68763962e-02,  2.23784580e-01 ])
    std = np.array([0.31285113, 0.21937416, 0.17070778, 0.14874465, 0.1200992,  0.11501499])#np.array([ 0.27346058, 0.23751527, 0.18529049, 0.12504842, 0.13313938 ,0.12407406 ])

    return scale * ((box_params - mean) / std)

def normalize_loc_params(box_params, scale=3):
    """ Normalize the box parameters for more stable learning utilizing the accumulated dataset statistics

    :param box_params: float array of shape [7] containing the box parameters
    :param scale: float scalar that scales the parameter distribution
    :return: normalized box parameters array of shape [7]
    """
    mean = np.array([ 0.0010283 , -0.02288815 , 0.20876316])#np.array([ 2.42144732e-01,  2.35105852e-01,  1.53590141e-01, -1.54968627e-04, -2.68763962e-02,  2.23784580e-01 ])
    std = np.array([ 0.14874465, 0.1200992,  0.11501499])#np.array([ 0.27346058, 0.23751527, 0.18529049, 0.12504842, 0.13313938 ,0.12407406 ])
    # mean=np.array([0.0015,-0.0311,0.2114])
    # std=np.array([0.0220,0.0177,0.0118])
    return scale * ((box_params - mean) / std)

def batch_torch_denormalize_loc_params(box_params, scale=3):
    """ Denormalize the box parameters utilizing the accumulated dateaset statistics

    :param box_params: float tensor of shape [N, 6] containing the 6 box parameters, where N is the number of boxes
    :param scale: float scalar that scales the parameter distribution
    :return: float tensor of shape [N, 6], the denormalized box parameters
    """
    mean = torch.tensor([ 0.0010283 , -0.02288815 , 0.20876316]).reshape(1,-1).float().cuda()#torch.tensor([ 2.42144732e-01,  2.35105852e-01,  1.53590141e-01, -1.54968627e-04, -2.68763962e-02,  2.23784580e-01 ]).reshape(1,-1).float().cuda()
    std = torch.tensor([0.14874465, 0.1200992,  0.11501499]).reshape(1,-1).float().cuda()#torch.tensor([ 0.27346058, 0.23751527, 0.18529049, 0.12504842, 0.13313938 ,0.12407406 ]).reshape(1,-1).float().cuda()
    # mean=torch.tensor([0.0015,-0.0311,0.2114]).reshape(1,-1).float().cuda()
    # std=torch.tensor([0.0220,0.0177,0.0118]).reshape(1,-1).float().cuda()
    return (box_params * std) / scale + mean


def quaternion_to_angle(quaternion):
    """
    将四元数转换为角度值。
    
    参数:
    quaternion -- 形状为 (N, 4) 的张量，包含 N 个四元数，格式为 (w, x, y, z)
    
    返回:
    angles -- 形状为 (N,) 的张量，包含每个四元数对应的旋转角度（单位为弧度）
    """
    # 提取四元数的标量部分 w
    # w = quaternion[:, 0]  # 选择第一列作为 w
    # x=quaternion[:,1]
    # y=quaternion[:,2]
    # z=quaternion[:,3]
    # w = torch.clamp(w, -1.0, 1.0)
    # # 计算旋转角度（弧度）
    # yaw = np.arctan2(2 * (y * w + x * z), 1 - 2 * (y**2 + x**2))
    r = R.from_quat(quaternion)
    euler = r.as_euler('xyz', degrees=True)
    # print("yaw:",euler[0])
    return torch.tensor(euler[0])



class my_Dataset(data.Dataset):
    def __init__(self,root,train_file_path,with_feats,if_val):
        self.train_file_path=train_file_path
        self.data_root=root
        self.with_feats=with_feats
        self.if_val=if_val
        self.max_num_obj=8

        self.goal_lines = []
        self.goal_file_path=[]
        with open(self.train_file_path, 'r', encoding='utf-8') as file:
            for line in file:
                line = line.strip()  # 去掉行首尾的空白字符
                if line.endswith("goal"):
                    self.goal_lines.append(line)
                    # goal_dir.append(line.split("_")[0])
        for i in range(len(self.goal_lines)):
            self.goal_file_path.append(os.path.join((self.goal_lines[i].split("_")[0]),self.goal_lines[i])+"_view-2.json")
        # goal_files=[]
        # '''检索含目标场景信息的文件，返回含目标文件名的列表'''
        # for filename in os.listdir(self.data_root):
        #     if '_goal_view-2.json' in filename:
        #         goal_files.append(filename)
        #         self.goal_files.append(filename)
        
    
    def get_label_name_to_global_id(self,file_path):
        labelName2InstanceId = {} #{'teapot_2': 8}
        instanceId2class = {} #{ 1: 'fork'}

        with open(file_path, 'r') as f:
            dict_out = json.load(f)
            for obj in dict_out['objects']:
                labelName2InstanceId[obj['name']] = obj['global_id']
                instanceId2class[obj['global_id']] = obj['class']
        if not labelName2InstanceId or not instanceId2class:
            raise ValueError(f"labelName2classId or classId2ClassName of {file_path} shouldn't be empty!")
        return labelName2InstanceId, instanceId2class
    

    def instance_id2mask(self,path_idx):

        #!labelName2InstanceId, e.g. {'plate_6': 10, '2362ec480b3e9baa4fd5721982c508ad_support_table': 109, 'fork_1': 1, 'knife_1': 2}
        #!instanceId2class {10: 'plate', 109: 'support_table', 1: 'fork', 2: 'knife'}
        labelName2InstanceId, instanceId2class = self.get_label_name_to_global_id(path_idx)
        keys = list(instanceId2class.keys()) #! all instance_ids  目标场景所有物体的全域id

        instance2mask = {}
        instance2mask[0] = 0 
        counter=0
        #! instance2mask {0: 0, 1: 1, 2: 2, 109: 3, 10: 4}
        for key in keys: #! 所有的instance_ids e.g., [1,2,109,10]
            # get objects from the selected list of classes of 3dssg
            scene_instance_id = key #!1
            instance2mask[scene_instance_id] = counter + 1 #
            counter += 1
        return instance2mask
           

    def __getitem__(self, idx):
        class_ids=[]#存储当前场景下物体类别的id
        bbox_es=[]#存储当前场景下物体的包围盒数据
        locations=[]
        angles=[]
        triples=[]
        names=[]
        scale=[]
        pad_mask=[]
        position_index=list(range(self.max_num_obj))
        path_idx=os.path.join(self.data_root,self.goal_file_path[idx])#布局信息文件路径
        scene_graph_path = path_idx.replace('_goal_view-2', '_goal_scene_graph')#图信息文件路径
        instance2mask=self.instance_id2mask(path_idx)
        if self.if_val:
                   print("布局文件路径:",path_idx)
        with open(path_idx, 'r', encoding='utf-8') as file:
            data = json.load(file)#
            object_data=data["objects"]
            for f in object_data:#每个物体的信息
                class_ids.append(f['class_id'])
                bbox_es.append(normalize_box_params(f['param6']))
                local_matrix=np.array(f['local_to_world_matrix'])
                pad_mask.append(0)
                locals=local_matrix[3,:3]
                if self.if_val:
                   print(locals)
                locations.append(normalize_loc_params(locals.tolist()))
                #locations.append((locals.tolist()))
                if self.if_val:
                    print(quaternion_to_angle(f['quaternion_xyzw']))
                angles.append(quaternion_to_angle(f['quaternion_xyzw']))
                
                # names[f["class"]]=f["name"]
                names.append((f["class"],f["name"]))
                scale.append(f["scale"])
                
        NUM=len(class_ids)

    
                
        with open(scene_graph_path, 'r', encoding='utf-8') as file: 
            data_graph=json.load(file)
            for r in data_graph["relationships"]:
                if r[0] in instance2mask.keys() and r[1] in instance2mask.keys():  #r[0], r[1] -> instance_id
                    subject = instance2mask[r[0]]-1 #! instance2mask[r[0] -> 实例在场景中的编号/索引 - 1, 最后一个node '_scene_' 放最后
                    object = instance2mask[r[1]]-1
                    predicate = r[2]+1
                    if subject >= 0 and object >= 0:
                         triples.append([subject, predicate, object])
                else:
                    continue   
        #padding 
        for i in range(self.max_num_obj - NUM):
            class_ids.append(0)
            locations.append([0,0,0])
            pad_mask.append(1)  
            angles.append(0)  
            names.append(('zero','zero'))
        datum = {
            "class_ids": class_ids,
            "angles":angles,
            "locations": locations,
             "all_names":names,
            "position_index":position_index,
            "pad_mask":pad_mask,
            "triples":triples
        }
        return self.convert_tensor(datum)
        #return datum  

            

        
    
    def __len__(self):
        return len(self.goal_file_path)
    

    def convert_tensor(self,datum):
        
        tensors={
            # "class_ids": torch.LongTensor(np.array(datum["class_ids"])),
            # "bbox_es": torch.FloatTensor(np.array(datum["bbox_es"])),
            # "locations": torch.FloatTensor(np.array(datum["locations"])),
            "angles":torch.FloatTensor(np.array(datum['angles'])).unsqueeze(-1),
            "triples":torch.LongTensor(np.array(datum['triples'])),

            "class_ids": torch.from_numpy(np.array(datum["class_ids"],dtype=np.int64)),
            "all_names":datum['all_names'],
            "locations": torch.from_numpy(np.array(datum["locations"],dtype=np.float32)),
            "position_index":torch.LongTensor(np.array(datum['position_index'])),
            "pad_mask": torch.LongTensor(np.array(datum["pad_mask"]))
         }
        return tensors
    
    def custom_collate_fn(self,batch):
    # 找到 triples 中的最大长度
        max_triples_len = max(len(item['triples']) for item in batch)
    # 对 triples 数据进行 padding
        padded_triples = [
        torch.cat(
            [item['triples'], torch.zeros(max_triples_len - len(item['triples']), 3)],
            dim=0
        ) if len(item['triples']) < max_triples_len else item['triples']
        for item in batch
    ]
    
        
    # 其他字段按默认方式处理
        collated_data = {
        "class_ids": torch.stack([item['class_ids'] for item in batch]),
        "locations": torch.stack([item['locations'] for item in batch]),
        "angles":torch.stack([item['angles'] for item in batch]),
        "triples": torch.stack(padded_triples),
        "position_index": torch.stack([item['position_index'] for item in batch]),
        "pad_mask": torch.stack([item['pad_mask'] for item in batch]),
        "names": [item["all_names"] for item in batch]
    }
        return collated_data

    
    

   
        
        
        
        
        
if __name__=="__main__":

    root="/home/lyb/PythonProject/ArrangeBot/sgbot_dataset/raw"
    train_file_path='/home/lyb/PythonProject/ArrangeBot/sgbot_dataset/train_scenes.txt'
    #root2="D:\\pythonhomework\\Project_Repetition\\SG-Bot\\sgbot_dataset\\7b4acb843fd4b0b335836c728d324152"
    #print(os.listdir(root))
    my_data=my_Dataset(root,train_file_path,None,None)
    # for i in files:
    #     print(i)
    # print(type(files))
    loc=[]
    print(len(my_data.goal_file_path))
    batch_size = 2 # 设置批次大小
    data_loader = data.DataLoader(my_data, batch_size=batch_size, shuffle=True,collate_fn=my_data.custom_collate_fn)

    # 输出一个批次的数据
    for batch in data_loader:
        # print(batch['locations'].shape)
        # print(batch['class_ids'].shape)
       
        print(batch)
        break
        # loc.append(batch["locations"])
        # print(batch['bbox_es'].shape)
        # print(batch['quaternion_xyzw'].shape)
        # 只输出一个批次的数据
    # print(loc)
#     loc=torch.cat(loc)
#     print(loc.shape)
#     mean_values = torch.mean(loc, axis=0)

# # 计算每列的方差
#     variance_values = torch.var(loc, axis=0)

#     print("每列的均值:", mean_values)
#     print("每列的方差:", variance_values)