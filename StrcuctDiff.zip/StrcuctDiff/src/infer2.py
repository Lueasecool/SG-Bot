import os
import argparse
import torch
import numpy as np
import pytorch_lightning as pl
from omegaconf import OmegaConf
import torch.nn as nn
import time
from tqdm import tqdm
# from StructDiffusion.data.semantic_arrangement import SemanticArrangementDataset
from StructDiffusion.language.tokenizer import Tokenizer
from StructDiffusion.models.pl_models import ConditionalPoseDiffusionModel
from StructDiffusion.diffusion.sampler import Sampler
from StructDiffusion.diffusion.pose_conversion import get_struct_objs_poses
from StructDiffusion.utils.files import get_checkpoint_path_from_dir, replace_config_for_testing_data
# from StructDiffusion.utils.batch_inference import move_pc_and_create_scene_simple, visualize_batch_pcs
from data_readfull import my_Dataset
from metric import validate_constrains,integer_relation
import pybullet as p
import pybullet_data


def batch_torch_denormalize_loc_params(box_params, scale=3):
    """ Denormalize the box parameters utilizing the accumulated dateaset statistics

    :param box_params: float tensor of shape [N, 6] containing the 6 box parameters, where N is the number of boxes
    :param scale: float scalar that scales the parameter distribution
    :return: float tensor of shape [N, 6], the denormalized box parameters
    """
    mean = torch.tensor([ 0.0010283 , -0.02288815 , 0.20876316]).reshape(1,-1).float()#torch.tensor([ 2.42144732e-01,  2.35105852e-01,  1.53590141e-01, -1.54968627e-04, -2.68763962e-02,  2.23784580e-01 ]).reshape(1,-1).float().cuda()
    std = torch.tensor([0.14874465, 0.1200992,  0.11501499]).reshape(1,-1).float()#torch.tensor([ 0.27346058, 0.23751527, 0.18529049, 0.12504842, 0.13313938 ,0.12407406 ]).reshape(1,-1).float().cuda()
    # mean=torch.tensor([0.0015,-0.0311,0.2114]).reshape(1,-1).float().cuda()
    # std=torch.tensor([0.0220,0.0177,0.0118]).reshape(1,-1).float().cuda()
    return (box_params * std) / scale + mean



def main2(args, cfg,vis=False):
    if vis:
        p.connect(p.GUI)
    pl.seed_everything(args.eval_random_seed)
    device = (torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu"))

    checkpoint_dir = os.path.join(cfg.WANDB.save_dir, cfg.WANDB.project, args.checkpoint_id, "checkpoints")
    #checkpoint_path = get_checkpoint_path_from_dir(checkpoint_dir)
    checkpoint_path="/home/lyb/PythonProject/StructDiffusion/wandb_logs/StructDiffusion/7j2or8k6/checkpoints/epoch=19999-step=520000.ckpt"
    if args.eval_mode == "infer":
        # tokenizer = Tokenizer(cfg.DATASET.vocab_dir)
        # override ignore_rgb for visualization
        cfg.DATASET.ignore_rgb = False
        #cfg.DATASET.ignore_rgb = True
       #dataset = SemanticArrangementDataset(split="test", tokenizer=tokenizer, **cfg.DATASET)
        root="/home/lyb/PythonProject/ArrangeBot/sgbot_dataset/raw"
        train_file_path='/home/lyb/PythonProject/ArrangeBot/sgbot_dataset/val_set.txt'
        
        dataset=my_Dataset(root,train_file_path,None,if_val=True)
        
        sampler = Sampler(ConditionalPoseDiffusionModel, checkpoint_path, device)

        # data_idxs = np.random.permutation(len(dataset))#对数据集的索引随机排列
        
        test_dataloader=torch.utils.data.DataLoader(dataset,batch_size=1,shuffle=True,
                                                    num_workers=0)
        error_locs_sum=[]
        error_angle_sum=[]
        integer_rate_sum=[]
        accuracy={}
        for k in ['left', 'right', 'front', 'behind', 'close by', 'standing on', 'total']:
            accuracy[k] = []
        for i ,data in enumerate(tqdm(test_dataloader)):
                                                       
            # print(data)
            # raw_datum = dataset.get_raw_data(di)
            # print(tokenizer.convert_structure_params_to_natural_language(raw_datum["sentence"]))
            # datum = dataset.convert_to_tensors(raw_datum, tokenizer)
            
            # batch = dataset.single_datum_to_batch(data, args.num_samples, device, inference_mode=True)
            # print(data)
            dec_triples=data['triples']
            num_poses = data["class_ids"].shape[1]
            goal_loc=batch_torch_denormalize_loc_params(data['locations'])
            xs = sampler.sample(data, num_poses)
            # print(xs[0][:,:,:3])
            # print(xs[0][:,:,3].shape)
            loc_pred=batch_torch_denormalize_loc_params(xs[0][:,:,:3].to("cpu"))
            angles_pred=torch.rad2deg(torch.arctan2(xs[0][:,:,3],xs[0][:,:,4]))
            ids=data["class_ids"]
            non_zero = ids[ids != 0].squeeze().tolist()
            target_pose=len(non_zero)
            angles_pred=angles_pred[:,:target_pose]
            goal_loc=goal_loc[:,:target_pose]
            
            
            loc_pred=loc_pred[:,:target_pose]
            
            # print("pred loc:",loc_pred[:,:target_pose])
            # print(" pred angle",angles_pred[:,:target_pose])
            # print("loc_pred shape:", loc_pred[:,:target_pose])
            # print("goal_loc shape:", goal_loc[:,:target_pose])
            # print("rendering obj ids:",data["class_ids"][:,:target_pose])
        #accuracy = validate_constrains(dec_triples, boxes_pred_den, angles_pred,rel_path, None, accuracy)
            mse_loss = nn.MSELoss(reduction='mean') 
            
            error_locs=mse_loss(loc_pred.detach().cpu(),goal_loc).item()
            print("err_loc:",error_locs)
            error_locs_sum.append(error_locs)
            goal_angle=data["angles"][:,:target_pose]
            error_angle=mse_loss(angles_pred.detach().cpu(),goal_angle.squeeze(-1)).item()
            error_angle_sum.append(error_angle)
            print("err_angle:",error_angle)
        #render(name_dict,scale,dec_objs.detach().cpu().numpy(), boxes_pred_den, angles_pred,quater_pred,loc_pred_den,goal_loc,store_path=img_path)
        
            name_dict={item[0][0]:item[1][0] for item in data['all_names']}
            if vis:
                
                p.resetSimulation()

                p.setAdditionalSearchPath(pybullet_data.getDataPath())
                p.setPhysicsEngineParameter(numSolverIterations=10)
            # print(loc_pred.squeeze(0))
                render_pybullet(name_dict,loc_pred.squeeze(0), angles_pred.squeeze(0),goal_loc.squeeze(0))

            
            accuracy = validate_constrains(dec_triples.squeeze(0), loc_pred.squeeze(0), None, accuracy)
            pred_xy=loc_pred.squeeze(0)[:,:2]
            goal_xy=goal_loc.squeeze(0)[:,:2]
            integer_rate=torch.clamp(integer_relation(pred_xy)/integer_relation(goal_xy),min=0.0,max=1.0)  if integer_relation(goal_xy)>0 else 1.0
        
            integer_rate_sum.append(integer_rate)
        
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
        
            print(accuracy)
            print(integer_rate)
            
            
            
            # struct_pose, pc_poses_in_struct = get_struct_objs_poses(xs[0])
            # print(struct_pose)
            # new_obj_xyzs = move_pc_and_create_scene_simple(batch["pcs"], struct_pose, pc_poses_in_struct)
            # visualize_batch_pcs(new_obj_xyzs, args.num_samples, limit_B=10, trimesh=True)

        keys = list(accuracy.keys())
    # left_acc=accuracy['left'].mean()
    #     right_acc=accuracy['ritgh'].mean()
    #     front_acc=accuracy['front'].mean()
    #     behind_acc=accuracy['behind'].mean()
    #     standing_on=accuracy['standing_on'].mean()
        
    #     totoal_acc=accuracy['total'].mean()
        file_path_for_output = os.path.join('/home/lyb/PythonProject/ArrangeBot', 'structdiffusion_accuracy_analysis.txt')
        with open(file_path_for_output, 'w') as file:
          for dic, typ in [(accuracy, "acc")]:
            lr_mean = np.mean([np.mean(dic[keys[0]]), np.mean(dic[keys[1]])])
            fb_mean = np.mean([np.mean(dic[keys[2]]), np.mean(dic[keys[3]])])
            close_mean = np.mean(dic[keys[4]])
            stand_mean = np.mean(dic[keys[5]])
            # symm_mean = np.mean(dic[keys[6]])
            total_mean = np.mean(dic[keys[6]])
            means_of_mean = np.mean([lr_mean, fb_mean, stand_mean, close_mean])
            print(
                '{} & L/R: {:.2f} & F/B: {:.2f} &  Close: {:.2f}  & Stand: {:.2f} & Total: &{:.2f}\n'.format(
                    typ, lr_mean, fb_mean, close_mean,stand_mean, total_mean))
            print('means of mean: {:.2f}'.format(means_of_mean))
            file.write(
                '{} & L/R: {:.2f} & F/B: {:.2f} &  Close: {:.2f}  & Stand: {:.2f} & Total: &{:.2f}\n'.format(
                    typ, lr_mean, fb_mean, close_mean,stand_mean, total_mean))
            file.write('means of mean: {:.4f}\n'.format(means_of_mean))
            trans_mean=np.mean(error_locs_sum)
            angle_mean=np.mean(error_angle_sum)
            integer_mean=np.mean(integer_rate_sum)
            print("mean of integer relation:{:.4f}\n".format(integer_mean))
            print("mean of translation error :{:.4f}\n".format(trans_mean))
            print("mean of angle error :{:.4f}\n".format(angle_mean))
            file.write("mean of translation:{:.4f}\n".format(trans_mean))
            file.write("mean of angle:{:.4f}\n".format(angle_mean))
            file.write("mean of integer relation:{:.4f}\n".format(integer_mean))
def render_pybullet(name_dict, loc_pred, angles_pred,goal_loc):
    logId = p.startStateLogging(p.STATE_LOGGING_PROFILE_TIMINGS, "visualShapeBench.json")
#useMaximalCoordinates is much faster then the default reduced coordinates (Featherstone)
    
#disable rendering during creation.
    p.configureDebugVisualizer(p.COV_ENABLE_RENDERING, 0)
    p.configureDebugVisualizer(p.COV_ENABLE_GUI, 0)
#disable tinyrenderer, software (CPU) renderer, we don't use it here
    p.configureDebugVisualizer(p.COV_ENABLE_TINY_RENDERER, 0)
    
    model_base_path = "/home/lyb/PythonProject/ArrangeBot/sgbot_dataset/models"
    
    keys=list(name_dict.keys())
    if 'zero' in keys:
        keys.remove('zero')
    z_error=[]
    
    for i in  range(len(keys)):
        name=name_dict[keys[i]]
        quater_pred=p.getQuaternionFromEuler([angles_pred[i],0,0])
        # print(loc_pred)
        # print(quater_pred)
        if "_support_table" not in name:
            ee=loc_pred[i,2]-goal_loc[i,2]
            z_error.append(ee) 
            if "fork" in name or "knife" in name or "spoon" in name :
                quater_pred=p.getQuaternionFromEuler([angles_pred[i],0,0])
            p.loadURDF((os.path.join(model_base_path,keys[i],f"{name}.urdf")),basePosition=loc_pred[i],baseOrientation=quater_pred,useFixedBase=False)
    for i in  range(len(keys)):
        name=name_dict[keys[i]]
        quater_pred=p.getQuaternionFromEuler([angles_pred[i],0,0])
        if "_support_table"  in name:
            name=name.replace("_support_table","")
            p.loadURDF((os.path.join(model_base_path,keys[i],f"{name}.urdf")),basePosition=[0,0,goal_loc[i,2]+min(z_error)],baseOrientation=quater_pred,useFixedBase=True)  
            p.loadURDF("plane100.urdf",basePosition=(0,0,0), useMaximalCoordinates=True)
    
    
    
    p.configureDebugVisualizer(p.COV_ENABLE_RENDERING, 1)
    p.stopStateLogging(logId)
    p.setGravity(0, 0, -10)
    p.setRealTimeSimulation(1)
    time.sleep(10)
  
     

if __name__ == "__main__":
    print("hello1")
    parser = argparse.ArgumentParser(description="infer")#创建命令行接口
    parser.add_argument("--base_config_file", help='base config yaml file',
                        default='./configs/base.yaml',
                        type=str)
    parser.add_argument("--config_file", help='config yaml file',
                        default='./configs/conditional_pose_diffusion.yaml',
                        type=str)
    parser.add_argument("--testing_data_config_file", help='config yaml file',
                        default='./configs/testing_data.yaml',
                        type=str)
    parser.add_argument("--checkpoint_id",
                        default="ConditionalPoseDiffusion",
                        type=str)
    parser.add_argument("--eval_mode",
                        default="infer",
                        type=str)
    parser.add_argument("--eval_random_seed",
                        default=42,
                        type=int)
    parser.add_argument("--num_samples",
                        default=10,
                        type=int)
    args = parser.parse_args()
    
    base_cfg = OmegaConf.load(args.base_config_file)
    cfg = OmegaConf.load(args.config_file)
   
    cfg = OmegaConf.merge(base_cfg, cfg)
   
    
    testing_data_cfg = OmegaConf.load(args.testing_data_config_file)
    testing_data_cfg = OmegaConf.merge(base_cfg, testing_data_cfg)
    replace_config_for_testing_data(cfg, testing_data_cfg)

    main2(args, cfg,vis=False)



