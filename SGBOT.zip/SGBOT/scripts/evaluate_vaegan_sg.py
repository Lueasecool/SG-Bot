from __future__ import print_function
import open3d as o3d # open3d needs to be imported before other packages!
import argparse
import os
import random
import numpy as np
import torch
import torch.nn.parallel
import torch.utils.data
import sys
import pybullet as p
import pybullet_data
import time
from itertools import combinations
from torch import nn
# 获取当前文件的路径
current_path = os.path.abspath(__file__)  # .../scripts/evaluate_vaegan.py

# 获取上一级路径
parent_path = os.path.dirname(current_path)# .../scripts
sys.path.append(os.path.dirname(parent_path))  #.../graphto3d/
sys.path.append('./graphto3d')
sys.path.append('.')
sys.path.append('./graphto3d/scripts')
from graphto3d.model.VAE import VAE
from graphto3d.dataset.dataset_use_features_gt import RIODatasetSceneGraph, collate_fn_vaegan, collate_fn_vaegan_points
from graphto3d.helpers.util import bool_flag, batch_torch_denormalize_box_params
from graphto3d.helpers.metrics import validate_constrains, validate_constrains_changes
from graphto3d.helpers.visualize_graph import run as vis_graph
from graphto3d.helpers.visualize_scene import render, render_per_shape
from graphto3d.model.atlasnet import AE_AtlasNet

# import extension.dist_chamfer as ext
# chamfer = ext.chamferDist()
import json

parser = argparse.ArgumentParser()
parser.add_argument('--num_points', type=int, default=5625, help='number of points in the shape')

parser.add_argument('--dataset', required=False, type=str, default="/home/lyb/PythonProject/ArrangeBot/sgbot_dataset", help="dataset path")
parser.add_argument('--dataset_raw', type=str, default='/home/lyb/PythonProject/ArrangeBot/sgbot_dataset/raw', help="dataset path of raw dataset")
parser.add_argument('--label_file', required=False, type=str, default='.obj', help="label file name")

parser.add_argument('--with_points', type=bool_flag, default=False, help="if false, only predicts layout")
parser.add_argument('--with_feats', type=bool_flag, default=True, help="Load Feats directly instead of points.")

parser.add_argument('--manipulate', default=True, type=bool_flag)
parser.add_argument('--path2atlas', required=False, default="/home/lyb/PythonProject/SG-Bot/AE_AtlasNet_add_cup_20230815T1718/atlasnet_add_cup.pth", type=str)
parser.add_argument('--path2atlas2', required=False, default="/home/lyb/PythonProject/SG-Bot/AE_AtlasNet2_20230408T2110/atlasnet2.pth", type=str)
parser.add_argument('--objs_features_gt', default="objs_features_gt_atlasnet_separate_cultery.json", type=str)
parser.add_argument('--exp', default='/home/lyb/PythonProject/SG-Bot/graphto3d_2_world_add_cup', help='experiment name')
parser.add_argument('--epoch', type=str, default='600', help='saved epoch')
parser.add_argument('--recompute_stats', type=bool_flag, default=False, help='Recomputes statistics of evaluated networks')
parser.add_argument('--visualize', default=False, type=bool_flag)
parser.add_argument('--export_3d', default=True, type=bool_flag, help='Export the generated shapes and boxes in json files for future use')
args = parser.parse_args()


def evaluate():
    print(torch.__version__)

    random.seed(48)
    torch.manual_seed(48)

    argsJson = os.path.join(args.exp, 'args.json')
    assert os.path.exists(argsJson), 'Could not find args.json for experiment {}'.format(args.exp)
    with open(argsJson) as j:
        modelArgs = json.load(j)

    saved_atlasnet_model = torch.load(args.path2atlas)
    point_ae = AE_AtlasNet(num_points=5625, bottleneck_size=128, nb_primitives=25)
    point_ae.load_state_dict(saved_atlasnet_model, strict=True)
    if torch.cuda.is_available():
        point_ae = point_ae.cuda()
    
    saved_atlasnet2_model = torch.load(args.path2atlas2)
    point_ae2 = AE_AtlasNet(num_points=5625, bottleneck_size=128, nb_primitives=25)
    point_ae2.load_state_dict(saved_atlasnet2_model, strict=True)
    if torch.cuda.is_available():
        point_ae2 = point_ae2.cuda()

    test_dataset_rels_changes = RIODatasetSceneGraph(
        root=args.dataset,
        atlas=point_ae,
        atlas2=point_ae2,
        path2atlas=args.path2atlas,
        path2atlas2=args.path2atlas2,
        root_raw=args.dataset_raw,
        label_file=args.label_file,
        split='train_scenes',
        npoints=args.num_points,
        use_points=args.with_points,
        use_scene_rels=modelArgs['use_scene_rels'],
        vae_baseline=modelArgs['network_type']=='sln',
        with_changes=True,
        eval=True,
        eval_type='relationship',
        with_feats=args.with_feats,
        features_gt=args.objs_features_gt)

    test_dataset_addition_changes = RIODatasetSceneGraph(
        root=args.dataset,
        atlas=point_ae,
        atlas2=point_ae2,
        path2atlas=args.path2atlas,
        path2atlas2=args.path2atlas2,
        root_raw=args.dataset_raw,
        label_file=args.label_file,
        split='train_scenes',
        npoints=args.num_points,
        use_points=args.with_points,
        use_scene_rels=modelArgs['use_scene_rels'],
        vae_baseline=modelArgs['network_type']=='sln',
        with_changes=True,
        eval=True,
        eval_type='addition',
        with_feats=args.with_feats,
        features_gt=args.objs_features_gt)

    # used to collect train statistics
    stats_dataset = RIODatasetSceneGraph(
        root=args.dataset,
        atlas=point_ae,
        atlas2=point_ae2,
        path2atlas=args.path2atlas,
        path2atlas2=args.path2atlas2,
        root_raw=args.dataset_raw,
        label_file=args.label_file,
        npoints=args.num_points,
        split='train_scenes',
        use_points=args.with_points,
        use_scene_rels=modelArgs['use_scene_rels'],
        with_changes=False,
        vae_baseline=modelArgs['network_type']=='sln',
        eval=False,
        with_feats=args.with_feats,
        features_gt=args.objs_features_gt)

    test_dataset_no_changes = RIODatasetSceneGraph(
        root=args.dataset,
        atlas=point_ae,
        atlas2=point_ae2,
        path2atlas=args.path2atlas,
        path2atlas2=args.path2atlas2,
        root_raw=args.dataset_raw,
        label_file=args.label_file,
        split='train_scenes',
        npoints=args.num_points,
        use_points=args.with_points,
        use_scene_rels=modelArgs['use_scene_rels'],
        vae_baseline=modelArgs['network_type']=='sln',
        with_changes=False,
        eval=True,
        with_feats=args.with_feats,
        features_gt=args.objs_features_gt)

    if args.with_points:
        collate_fn = collate_fn_vaegan_points
    else:
        collate_fn = collate_fn_vaegan

    # test_dataloader_rels_changes = torch.utils.data.DataLoader(
    #     test_dataset_rels_changes,
    #     batch_size=1,
    #     collate_fn=collate_fn,
    #     shuffle=False,
    #     num_workers=0)
    #
    # test_dataloader_add_changes = torch.utils.data.DataLoader(
    #     test_dataset_addition_changes,
    #     batch_size=1,
    #     collate_fn=collate_fn,
    #     shuffle=False,
    #     num_workers=0)

    # dataloader to collect train data statistics
    stats_dataloader = torch.utils.data.DataLoader(
        stats_dataset,
        batch_size=1,
        collate_fn=collate_fn,
        shuffle=False,
        num_workers=0)

    test_dataloader_no_changes = torch.utils.data.DataLoader(
        test_dataset_no_changes,
        batch_size=1,
        collate_fn=collate_fn,
        shuffle=False,
        num_workers=0)

    modeltype_ = modelArgs['network_type']
    replacelatent_ = modelArgs['replace_latent'] if 'replace_latent' in modelArgs else None
    with_changes_ = modelArgs['with_changes'] if 'with_changes' in modelArgs else None

    model = VAE(type=modeltype_, vocab=test_dataset_no_changes.vocab, replace_latent=replacelatent_,
                with_changes=with_changes_, residual=modelArgs['residual'])
    model.load_networks(exp=args.exp, epoch=args.epoch)
    if torch.cuda.is_available():
        model = model.cuda()

    model = model.eval()
    point_ae = point_ae.eval()

    model.compute_statistics(exp=args.exp, epoch=args.epoch, stats_dataloader=stats_dataloader, force=args.recompute_stats)

    def reseed():
        np.random.seed(47)
        torch.manual_seed(47)
        random.seed(47)

    # print('\nEditing Mode - Additions')
    # reseed()
    # validate_constrains_loop_w_changes(test_dataloader_add_changes, model, atlas=point_ae)
    # reseed()
    # print('\nEditing Mode - Relationship changes')
    # validate_constrains_loop_w_changes(test_dataloader_rels_changes, model, atlas=point_ae)

    reseed()
    print('\nGeneration Mode')
    validate_constrains_loop(test_dataloader_no_changes, model, point_ae=point_ae, export_3d=args.export_3d)




        




def validate_constrains_loop(testdataloader, model, point_ae=None, export_3d=False):

    accuracy = {}
    for k in ['left', 'right', 'front', 'behind', 'close by', 'symmetrical to', 'total']:
        # compute validation for these relation categories
        accuracy[k] = []

    all_pred_shapes_exp = {} # for export
    all_pred_boxes_exp = {}

    visualize_num = 0
    error_locs_sum=[]
    integer_rate_sum=[]
    for i, data in enumerate(testdataloader, 0):
        print(f"now processing {data['scene_id']}")
        
    
        dec_objs, dec_triples, dec_shape_priors = data['decoder']['objs'], data['decoder']['triples'], data['decoder']['shape_priors']
        goal_loc=batch_torch_denormalize_box_params(data['decoder']['boxes'].cuda())[:,3:]
        instances = data['instance_id'][0]
        scan = data['scene_id'][0]

            
            
        
        name_dict=data['labelname']
        print(name_dict)
        dec_objs, dec_triples, dec_shape_priors = dec_objs.cuda(), dec_triples.cuda(), dec_shape_priors.cuda()

        all_pred_boxes = []

        with torch.no_grad():
            boxes_pred, (points_pred, shape_enc_pred) = model.sample_box_and_shape(point_ae, dec_objs, dec_triples, dec_shape_priors)
            """ temp = np.array(points_pred.tolist())
            max_vals = np.max(temp, axis=1)
            min_vals = np.min(temp, axis=1)
            print(min_vals, max_vals)

            result_path = args.exp
            name = 'pred_point_cloud_'+str(np.random.randint(0,100))
            shape_filename = os.path.join(result_path, name + '.json')
            json.dump(points_pred.tolist(), open(shape_filename, 'w')) """
        # print(boxes_pred,points_pred,shape_enc_pred)
        print(boxes_pred)
        if model.type_ != 'sln':
            boxes_pred_den = batch_torch_denormalize_box_params(boxes_pred)
            #! 反归一化: 将它们从归一化的参数空间转换回原始参数空间。这对于在处理场景中的物体边界框时很有用，因为归一化处理可以使训练和优化过程更加稳定和高效。
        else:
            boxes_pred_den = boxes_pred

        if export_3d:
            boxes_pred_exp = boxes_pred_den.detach().cpu().numpy().tolist()
            if model.type_ != 'sln':
                # save point encodings
                shapes_pred_exp = shape_enc_pred.detach().cpu().numpy().tolist()

            for i in range(len(shapes_pred_exp)):
                if dec_objs[i] not in testdataloader.dataset.point_classes_idx:
                    shapes_pred_exp[i] = []
                    raise ValueError(f"{dec_objs[i]} not in {testdataloader.dataset.point_classes_idx}")
            shapes_pred_exp = list(shapes_pred_exp)

            if scan not in all_pred_shapes_exp:
                all_pred_boxes_exp[scan] = {}
                all_pred_shapes_exp[scan] = {}

            all_pred_boxes_exp[scan]['objs'] = list(instances)
            all_pred_shapes_exp[scan]['objs'] = list(instances)
            for i in range(len(dec_objs) - 1):
                all_pred_boxes_exp[scan][instances[i]] = list(boxes_pred_exp[i])
                all_pred_shapes_exp[scan][instances[i]] = list(shapes_pred_exp[i])

        if args.visualize:
            p.connect(p.GUI)
                  
            pred_loc=boxes_pred_den[:,3:]
            p.resetSimulation()

            p.setAdditionalSearchPath(pybullet_data.getDataPath())
            p.setPhysicsEngineParameter(numSolverIterations=10)
            render_pybullet(name_dict,pred_loc,None)
        pred_loc=boxes_pred_den[:,3:]
        visualize_num+=1

        all_pred_boxes.append(boxes_pred_den.cpu().detach())

        # compute constraints accuracy through simple geometric rules
        accuracy = validate_constrains(dec_triples, boxes_pred, None, None, model.vocab, accuracy, with_norm=model.type_ != 'sln')

        pred_xy=pred_loc.squeeze(0)[:,:2]
        goal_xy=goal_loc.squeeze(0)[:,:2]
        integer_rate=torch.clamp(integer_relation(pred_xy)/integer_relation(goal_xy),min=0.0,max=1.0)  if integer_relation(goal_xy)>0 else 1.0
        mse_loss = nn.MSELoss(reduction='mean') 
        print(accuracy)
        
        error_locs=mse_loss(pred_loc,goal_loc).item()
        print("err_loc:",error_locs)
        print(integer_rate)
        error_locs_sum.append(error_locs)
        integer_rate_sum.append(integer_rate)
        
    keys = list(accuracy.keys())
    # left_acc=accuracy['left'].mean()
    #     right_acc=accuracy['ritgh'].mean()
    #     front_acc=accuracy['front'].mean()
    #     behind_acc=accuracy['behind'].mean()
    #     standing_on=accuracy['standing_on'].mean()
        
    #     totoal_acc=accuracy['total'].mean()
    file_path_for_output = os.path.join('/home/lyb/PythonProject/ArrangeBot', 'sgbot_accuracy_analysis.txt')
    with open(file_path_for_output, 'w') as file:
          for dic, typ in [(accuracy, "acc")]:
            lr_mean = np.mean([np.mean(dic[keys[0]]), np.mean(dic[keys[1]])])
            fb_mean = np.mean([np.mean(dic[keys[2]]), np.mean(dic[keys[3]])])
            close_mean = np.mean(dic[keys[4]])
            stand_mean = np.mean(dic[keys[5]])
            # symm_mean = np.mean(dic[keys[6]])
            total_mean = np.mean(dic[keys[6]])
            means_of_mean = np.mean([lr_mean, fb_mean, stand_mean, close_mean])
            print(
                '{} & L/R: {:.2f} & F/B: {:.2f} &  Close: {:.2f}  & Stand: {:.2f} & Total: &{:.2f}\n'.format(
                    typ, lr_mean, fb_mean, close_mean,stand_mean, total_mean))
            print('means of mean: {:.2f}'.format(means_of_mean))
            file.write(
                '{} & L/R: {:.2f} & F/B: {:.2f} &  Close: {:.2f}  & Stand: {:.2f} & Total: &{:.2f}\n'.format(
                    typ, lr_mean, fb_mean, close_mean,stand_mean, total_mean))
            file.write('means of mean: {:.4f}\n'.format(means_of_mean))
            trans_mean=np.mean(error_locs_sum)
            integer_mean=np.mean(integer_rate_sum)
            print("mean of integer relation:{:.4f}\n".format(integer_mean))
            print("mean of translation error :{:.4f}\n".format(trans_mean))
            file.write("mean of translation:{:.4f}\n".format(trans_mean))
            file.write("mean of integer relation:{:.4f}\n".format(integer_mean))   
        
        



def integer_relation(pred_xy,threshold=4e-4):
    if (len) (pred_xy)<3:
        print("len is too small")
        return 1.0
    
    total_set=0
    collinear=0
    for combo in combinations(pred_xy,3):
        total_set+=1
        (x1,y1),(x2,y2),(x3,y3)=combo
    
        if abs((y2-y1)*(x3-x1)- (y3-y1)*(x2-x1))<threshold:
            collinear+=1
    return torch.tensor(collinear/total_set) if total_set> 0 else torch.tensor(0.0)

def render_pybullet(name_dict, pred_loc,render_type='scene'
               ):
    #os.makedirs(store_path,exist_ok=True)
    
    
   
   
    logId = p.startStateLogging(p.STATE_LOGGING_PROFILE_TIMINGS, "visualShapeBench.json")
#useMaximalCoordinates is much faster then the default reduced coordinates (Featherstone)
    
#disable rendering during creation.
    p.configureDebugVisualizer(p.COV_ENABLE_RENDERING, 0)
    p.configureDebugVisualizer(p.COV_ENABLE_GUI, 0)
#disable tinyrenderer, software (CPU) renderer, we don't use it here
    p.configureDebugVisualizer(p.COV_ENABLE_TINY_RENDERER, 0)
    model_base_path = "/home/lyb/PythonProject/ArrangeBot/sgbot_dataset/models"
    urdf_path=[]
    keys=list(name_dict[0].keys())
    z_error=[]
    for i in  range(len(keys)):
        name=keys[i]
        if "_support_table" not in name:
            # ee=boxes[i,5]-goal_loc[i,-1]
            # z_error.append(ee) 
            class_name=name.split("_")[0]
            print(class_name)
            if "fork" in name or "knife" in name or "spoon" in name:
                p.loadURDF((os.path.join(model_base_path,class_name,f"{name}.urdf")),basePosition=pred_loc[i,:],baseOrientation=(0.8,0,0,0.2))
            else:
                p.loadURDF((os.path.join(model_base_path,class_name,f"{name}.urdf")),basePosition=pred_loc[i,:],baseOrientation=(0,0,0,1))
    for i in  range(len(keys)):
        name=keys[i]
        if "_support_table"  in name:
            name=name.replace("_support_table","")
            path=os.path.join(model_base_path,"support_table",f"{name}.urdf")
            print(path)
            p.loadURDF(path,basePosition=pred_loc[i,:],baseOrientation=[0,0,0,1],useFixedBase=True)  
            p.loadURDF("plane100.urdf",basePosition=(0,0,0), useMaximalCoordinates=True)
    
    
    
    p.configureDebugVisualizer(p.COV_ENABLE_RENDERING, 1)
    p.stopStateLogging(logId)
    p.setGravity(0, 0, -10)
    p.setRealTimeSimulation(1)
    time.sleep(10)






if __name__ == "__main__": evaluate()
